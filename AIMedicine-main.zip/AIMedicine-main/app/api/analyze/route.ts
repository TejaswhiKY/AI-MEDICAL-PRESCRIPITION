import { type NextRequest, NextResponse } from "next/server"
import { medicalAnalyzer } from "@/lib/medical-analyzer"
import type { AnalysisRequest } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { medications, patient, analysisType = "comprehensive" } = body

    // Validate input
    if (!medications || !Array.isArray(medications) || medications.length === 0) {
      return NextResponse.json({ status: "error", message: "At least one medication is required" }, { status: 400 })
    }

    if (!patient || typeof patient.age !== "number") {
      return NextResponse.json({ status: "error", message: "Patient age is required" }, { status: 400 })
    }

    const analysisRequest: AnalysisRequest = {
      medications,
      patient,
      analysisType,
    }

    const analysisResult = await medicalAnalyzer.performComprehensiveAnalysis(analysisRequest)

    const response = {
      status: "success",
      message: "Analysis completed successfully",
      data: {
        ...analysisResult,
        timestamp: new Date().toISOString(),
        analysisType,
      },
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("Analysis API error:", error)
    return NextResponse.json(
      {
        status: "error",
        message: error instanceof Error ? error.message : "Analysis failed",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

// Health check endpoint
export async function GET() {
  return NextResponse.json({
    status: "healthy",
    message: "Medical Analysis API is running",
    timestamp: new Date().toISOString(),
    features: [
      "Drug interaction analysis",
      "Dosage verification",
      "Alternative medication finder",
      "Comprehensive medical analysis",
    ],
  })
}
