"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { MedicationInput } from "@/components/medication-input"
import { AnalysisResults } from "@/components/analysis-results"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Heart, User, Info, BookOpen, AlertTriangle } from "lucide-react"
import type { Medication, Patient, AnalysisResponse } from "@/lib/types"

export default function PatientPage() {
  const [medications, setMedications] = useState<Medication[]>([])
  const [patient, setPatient] = useState<Patient>({ age: 0 })
  const [analysisResult, setAnalysisResult] = useState<AnalysisResponse | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleCheckMedications = async () => {
    if (medications.length === 0 || patient.age <= 0) {
      setError("Please add your medications and age")
      return
    }

    setIsAnalyzing(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          medications,
          patient,
          analysisType: "comprehensive",
        }),
      })

      const data = await response.json()

      if (data.status === "success") {
        setAnalysisResult(data.data)
      } else {
        setError(data.message || "Analysis failed")
      }
    } catch (err) {
      setError("Network error. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Heart className="h-8 w-8 text-purple-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Patient Medication Portal</h1>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Understand your medications and check for potential interactions
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Important Notice */}
        <Card className="mb-8 border-amber-200 bg-amber-50 dark:bg-amber-900/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-amber-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-amber-800 dark:text-amber-200 mb-1">Important Medical Disclaimer</h3>
                <p className="text-sm text-amber-700 dark:text-amber-300">
                  This tool is for educational purposes only and should not replace professional medical advice. Always
                  consult with your healthcare provider or pharmacist before making any changes to your medications.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            {/* Personal Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Your Information
                </CardTitle>
                <CardDescription>Help us provide personalized medication insights</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="your-age">Your Age</Label>
                    <Input
                      id="your-age"
                      type="number"
                      placeholder="e.g., 35"
                      value={patient.age || ""}
                      onChange={(e) => setPatient({ ...patient, age: Number.parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="your-weight">Weight (optional)</Label>
                    <Input
                      id="your-weight"
                      type="number"
                      placeholder="kg"
                      value={patient.weight || ""}
                      onChange={(e) => setPatient({ ...patient, weight: Number.parseInt(e.target.value) || undefined })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="your-conditions">Health Conditions (optional)</Label>
                  <Input
                    id="your-conditions"
                    placeholder="e.g., High blood pressure, Diabetes"
                    onChange={(e) =>
                      setPatient({
                        ...patient,
                        conditions: e.target.value
                          .split(",")
                          .map((c) => c.trim())
                          .filter(Boolean),
                      })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="your-allergies">Known Drug Allergies (optional)</Label>
                  <Input
                    id="your-allergies"
                    placeholder="e.g., Penicillin, Aspirin"
                    onChange={(e) =>
                      setPatient({
                        ...patient,
                        allergies: e.target.value
                          .split(",")
                          .map((a) => a.trim())
                          .filter(Boolean),
                      })
                    }
                  />
                </div>
              </CardContent>
            </Card>

            {/* Medications */}
            <MedicationInput medications={medications} onMedicationsChange={setMedications} />

            {/* Educational Resources */}
            <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-purple-800 dark:text-purple-200">
                  <BookOpen className="h-5 w-5" />
                  Medication Safety Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-purple-700 dark:text-purple-300 space-y-2">
                  <li>• Always take medications as prescribed by your doctor</li>
                  <li>• Keep an updated list of all your medications</li>
                  <li>• Inform all healthcare providers about your current medications</li>
                  <li>• Never stop taking prescribed medications without consulting your doctor</li>
                  <li>• Report any unusual side effects to your healthcare provider</li>
                </ul>
              </CardContent>
            </Card>

            {/* Check Button */}
            <Card>
              <CardContent className="pt-6">
                {error && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}
                <Button
                  onClick={handleCheckMedications}
                  disabled={isAnalyzing || medications.length === 0 || patient.age <= 0}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  size="lg"
                >
                  {isAnalyzing ? (
                    <>
                      <LoadingSpinner className="mr-2" />
                      Checking Your Medications...
                    </>
                  ) : (
                    <>
                      <Heart className="mr-2 h-5 w-5" />
                      Check My Medications
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div>
            {analysisResult ? (
              <div className="space-y-4">
                <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
                  <CardHeader>
                    <CardTitle className="text-purple-800 dark:text-purple-200">Your Medication Report</CardTitle>
                    <CardDescription className="text-purple-700 dark:text-purple-300">
                      Educational information about your medications
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Safety Assessment:</span>
                        <Badge
                          className={
                            analysisResult.interactions.length === 0
                              ? "bg-green-100 text-green-800"
                              : analysisResult.interactions.some((i) => i.severity === "severe")
                                ? "bg-red-100 text-red-800"
                                : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {analysisResult.interactions.length === 0
                            ? "No Concerns Found"
                            : analysisResult.interactions.some((i) => i.severity === "severe")
                              ? "Consult Your Doctor"
                              : "Minor Concerns"}
                        </Badge>
                      </div>
                      {analysisResult.interactions.length > 0 && (
                        <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md">
                          <p className="text-sm text-blue-800 dark:text-blue-200 font-medium mb-1">Next Steps:</p>
                          <p className="text-sm text-blue-700 dark:text-blue-300">
                            Please discuss these findings with your healthcare provider or pharmacist at your next
                            appointment.
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                <AnalysisResults result={analysisResult} />
              </div>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 mb-2">Ready to Help</h3>
                  <p className="text-gray-500">
                    Add your medications and personal information to get educational insights about potential
                    interactions and safety considerations.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
