"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { MedicationInput } from "@/components/medication-input"
import { AnalysisResults } from "@/components/analysis-results"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Pill, User, ShieldCheck, AlertCircle } from "lucide-react"
import type { Medication, Patient, AnalysisResponse } from "@/lib/types"

export default function PharmacistPage() {
  const [medications, setMedications] = useState<Medication[]>([])
  const [patient, setPatient] = useState<Patient>({ age: 0 })
  const [prescriptionNotes, setPrescriptionNotes] = useState("")
  const [analysisResult, setAnalysisResult] = useState<AnalysisResponse | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleVerifyPrescription = async () => {
    if (medications.length === 0 || patient.age <= 0) {
      setError("Please add medications and patient age for verification")
      return
    }

    setIsAnalyzing(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          medications,
          patient,
          analysisType: "comprehensive",
          notes: prescriptionNotes,
        }),
      })

      const data = await response.json()

      if (data.status === "success") {
        setAnalysisResult(data.data)
      } else {
        setError(data.message || "Verification failed")
      }
    } catch (err) {
      setError("Network error. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Pill className="h-8 w-8 text-green-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Pharmacist Verification Portal</h1>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Verify prescriptions, check dosages, and find safe alternatives
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Verification Section */}
          <div className="space-y-6">
            {/* Prescription Information */}
            <Card className="border-green-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <ShieldCheck className="h-5 w-5" />
                  Prescription Verification
                </CardTitle>
                <CardDescription>Verify prescription safety and appropriateness</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="prescription-notes">Prescription Notes/Instructions</Label>
                  <Textarea
                    id="prescription-notes"
                    placeholder="Enter any special instructions, concerns, or notes from the prescribing physician..."
                    value={prescriptionNotes}
                    onChange={(e) => setPrescriptionNotes(e.target.value)}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Patient Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Patient Demographics
                </CardTitle>
                <CardDescription>Patient information for dosage verification</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="patient-age">Age (years)</Label>
                    <Input
                      id="patient-age"
                      type="number"
                      placeholder="e.g., 45"
                      value={patient.age || ""}
                      onChange={(e) => setPatient({ ...patient, age: Number.parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="patient-weight">Weight (kg)</Label>
                    <Input
                      id="patient-weight"
                      type="number"
                      placeholder="e.g., 70"
                      value={patient.weight || ""}
                      onChange={(e) => setPatient({ ...patient, weight: Number.parseInt(e.target.value) || undefined })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="patient-conditions">Known Conditions</Label>
                  <Input
                    id="patient-conditions"
                    placeholder="e.g., Diabetes, Hypertension, Kidney disease"
                    onChange={(e) =>
                      setPatient({
                        ...patient,
                        conditions: e.target.value
                          .split(",")
                          .map((c) => c.trim())
                          .filter(Boolean),
                      })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="patient-allergies">Drug Allergies</Label>
                  <Input
                    id="patient-allergies"
                    placeholder="e.g., Penicillin, Sulfa drugs, NSAIDs"
                    onChange={(e) =>
                      setPatient({
                        ...patient,
                        allergies: e.target.value
                          .split(",")
                          .map((a) => a.trim())
                          .filter(Boolean),
                      })
                    }
                  />
                </div>
              </CardContent>
            </Card>

            {/* Medications */}
            <MedicationInput medications={medications} onMedicationsChange={setMedications} />

            {/* Verification Actions */}
            <Card>
              <CardContent className="pt-6">
                {error && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-center gap-2">
                    <AlertCircle className="h-4 w-4" />
                    {error}
                  </div>
                )}
                <div className="grid grid-cols-1 gap-3">
                  <Button
                    onClick={handleVerifyPrescription}
                    disabled={isAnalyzing || medications.length === 0 || patient.age <= 0}
                    className="bg-green-600 hover:bg-green-700"
                    size="lg"
                  >
                    {isAnalyzing ? (
                      <>
                        <LoadingSpinner className="mr-2" />
                        Verifying Prescription...
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="mr-2 h-5 w-5" />
                        Verify Prescription Safety
                      </>
                    )}
                  </Button>
                  <div className="grid grid-cols-2 gap-2">
                    <Badge variant="outline" className="justify-center py-2">
                      Dosage Check
                    </Badge>
                    <Badge variant="outline" className="justify-center py-2">
                      Interaction Scan
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div>
            {analysisResult ? (
              <div className="space-y-4">
                <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
                  <CardHeader>
                    <CardTitle className="text-green-800 dark:text-green-200">Pharmacist Verification Report</CardTitle>
                    <CardDescription className="text-green-700 dark:text-green-300">
                      Professional analysis for prescription dispensing decision
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Overall Safety Assessment:</span>
                      <Badge
                        className={
                          analysisResult.confidence > 0.8
                            ? "bg-green-100 text-green-800"
                            : analysisResult.confidence > 0.6
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                        }
                      >
                        {analysisResult.confidence > 0.8
                          ? "Safe to Dispense"
                          : analysisResult.confidence > 0.6
                            ? "Caution Required"
                            : "Consult Physician"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
                <AnalysisResults result={analysisResult} />
              </div>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <ShieldCheck className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 mb-2">Ready for Verification</h3>
                  <p className="text-gray-500">
                    Enter prescription details and patient information to perform comprehensive safety verification.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
