import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Activity, Shield, Users, Pill } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">MedVerify AI</h1>
            </div>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              Powered by AI
            </Badge>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            AI-Powered Medical Prescription Verification
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Analyze drug interactions, verify dosages, and find safe alternatives using advanced NLP models and
            comprehensive medical databases.
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-blue-600" />
                <CardTitle>Drug Interaction Analysis</CardTitle>
              </div>
              <CardDescription>
                Identify potential interactions between prescribed medications with scientific accuracy.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                <li>• Real-time interaction detection</li>
                <li>• Scientific drug name mapping</li>
                <li>• RxCUI identification</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Pill className="h-6 w-6 text-green-600" />
                <CardTitle>Dosage Verification</CardTitle>
              </div>
              <CardDescription>
                Verify correct dosages based on patient age, weight, and medical conditions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                <li>• Age-appropriate dosing</li>
                <li>• Safety threshold checks</li>
                <li>• Alternative recommendations</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Users className="h-6 w-6 text-purple-600" />
                <CardTitle>Multi-User Support</CardTitle>
              </div>
              <CardDescription>Designed for healthcare providers, pharmacists, and informed patients.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                <li>• Healthcare provider tools</li>
                <li>• Pharmacist verification</li>
                <li>• Patient education</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* User Scenarios */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
            <CardHeader>
              <CardTitle className="text-blue-800 dark:text-blue-200">Healthcare Provider</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-blue-700 dark:text-blue-300 mb-4">
                Input prescribed medications and get comprehensive interaction analysis with scientific drug names and
                RxCUIs.
              </p>
              <Link href="/provider">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Provider Dashboard</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
            <CardHeader>
              <CardTitle className="text-green-800 dark:text-green-200">Pharmacist</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-green-700 dark:text-green-300 mb-4">
                Verify dosages and check for safe alternatives based on patient demographics and conditions.
              </p>
              <Link href="/pharmacist">
                <Button className="w-full bg-green-600 hover:bg-green-700">Pharmacist Tools</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardHeader>
              <CardTitle className="text-purple-800 dark:text-purple-200">Patient</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-purple-700 dark:text-purple-300 mb-4">
                Understand medication interactions and get safe dosage recommendations for your prescriptions.
              </p>
              <Link href="/patient">
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Patient Portal</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="max-w-2xl mx-auto bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Start Verifying Prescriptions</h3>
              <p className="mb-6 opacity-90">
                Choose your role to access specialized tools and features designed for your needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/provider">
                  <Button variant="secondary" size="lg" className="w-full sm:w-auto">
                    Healthcare Provider
                  </Button>
                </Link>
                <Link href="/pharmacist">
                  <Button variant="secondary" size="lg" className="w-full sm:w-auto">
                    Pharmacist
                  </Button>
                </Link>
                <Link href="/patient">
                  <Button variant="secondary" size="lg" className="w-full sm:w-auto">
                    Patient
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
