"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MedicationInput } from "@/components/medication-input"
import { AnalysisResults } from "@/components/analysis-results"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Activity, User, Stethoscope } from "lucide-react"
import type { Medication, Patient, AnalysisResponse } from "@/lib/types"

export default function ProviderPage() {
  const [medications, setMedications] = useState<Medication[]>([])
  const [patient, setPatient] = useState<Patient>({ age: 0 })
  const [analysisResult, setAnalysisResult] = useState<AnalysisResponse | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleAnalyze = async () => {
    if (medications.length === 0 || patient.age <= 0) {
      setError("Please add at least one medication and enter patient age")
      return
    }

    setIsAnalyzing(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          medications,
          patient,
          analysisType: "comprehensive",
        }),
      })

      const data = await response.json()

      if (data.status === "success") {
        setAnalysisResult(data.data)
      } else {
        setError(data.message || "Analysis failed")
      }
    } catch (err) {
      setError("Network error. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Stethoscope className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Healthcare Provider Dashboard</h1>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Comprehensive drug interaction and prescription analysis
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            {/* Patient Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Patient Information
                </CardTitle>
                <CardDescription>Enter basic patient demographics for analysis</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="age">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="e.g., 65"
                      value={patient.age || ""}
                      onChange={(e) => setPatient({ ...patient, age: Number.parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="weight">Weight (kg) - Optional</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="e.g., 70"
                      value={patient.weight || ""}
                      onChange={(e) => setPatient({ ...patient, weight: Number.parseInt(e.target.value) || undefined })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="conditions">Medical Conditions - Optional</Label>
                  <Input
                    id="conditions"
                    placeholder="e.g., Diabetes, Hypertension (comma-separated)"
                    onChange={(e) =>
                      setPatient({
                        ...patient,
                        conditions: e.target.value
                          .split(",")
                          .map((c) => c.trim())
                          .filter(Boolean),
                      })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="allergies">Known Allergies - Optional</Label>
                  <Input
                    id="allergies"
                    placeholder="e.g., Penicillin, Sulfa (comma-separated)"
                    onChange={(e) =>
                      setPatient({
                        ...patient,
                        allergies: e.target.value
                          .split(",")
                          .map((a) => a.trim())
                          .filter(Boolean),
                      })
                    }
                  />
                </div>
              </CardContent>
            </Card>

            {/* Medications */}
            <MedicationInput medications={medications} onMedicationsChange={setMedications} />

            {/* Analysis Button */}
            <Card>
              <CardContent className="pt-6">
                {error && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                    {error}
                  </div>
                )}
                <Button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || medications.length === 0 || patient.age <= 0}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  {isAnalyzing ? (
                    <>
                      <LoadingSpinner className="mr-2" />
                      Analyzing Prescriptions...
                    </>
                  ) : (
                    <>
                      <Activity className="mr-2 h-5 w-5" />
                      Analyze Drug Interactions
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div>
            {analysisResult ? (
              <AnalysisResults result={analysisResult} />
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <Activity className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 mb-2">Ready for Analysis</h3>
                  <p className="text-gray-500">
                    Add medications and patient information, then click "Analyze Drug Interactions" to get started.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
