// Medical analysis service using Hugging Face models

import { huggingFaceClient } from "./huggingface-client"
import type { AnalysisRequest, AnalysisResponse, DrugInteraction, DosageVerification, Alternative } from "./types"

export class MedicalAnalyzer {
  async performComprehensiveAnalysis(request: AnalysisRequest): Promise<AnalysisResponse> {
    const { medications, patient, analysisType } = request

    try {
      // Extract medication names for analysis
      const medicationNames = medications.map((med) => med.name)

      // Perform different types of analysis based on request
      const [interactions, dosageVerifications, alternatives] = await Promise.all([
        this.analyzeInteractions(medicationNames),
        this.verifyDosages(medications, patient.age),
        this.findAlternatives(medications, patient),
      ])

      // Generate summary
      const summary = this.generateSummary(interactions, dosageVerifications, alternatives)

      // Calculate overall confidence
      const confidence = this.calculateConfidence(interactions, dosageVerifications, alternatives)

      return {
        interactions,
        dosageVerifications,
        alternatives,
        summary,
        confidence,
      }
    } catch (error) {
      console.error("Comprehensive analysis failed:", error)
      throw new Error("Analysis failed. Please try again.")
    }
  }

  private async analyzeInteractions(medications: string[]): Promise<DrugInteraction[]> {
    if (medications.length < 2) {
      return []
    }

    try {
      const result = await huggingFaceClient.analyzeDrugInteractions(medications)
      return result.interactions || []
    } catch (error) {
      console.error("Interaction analysis error:", error)
      return []
    }
  }

  private async verifyDosages(medications: any[], patientAge: number): Promise<DosageVerification[]> {
    const verifications: DosageVerification[] = []

    for (const med of medications) {
      try {
        const result = await huggingFaceClient.verifyDosage(med.name, med.dosage, patientAge)

        verifications.push({
          medication: med.name,
          prescribedDose: med.dosage,
          recommendedDose: result.recommendedRange || med.dosage,
          isAppropriate: result.isAppropriate,
          warnings: result.warnings || [],
        })
      } catch (error) {
        console.error(`Dosage verification error for ${med.name}:`, error)
        verifications.push({
          medication: med.name,
          prescribedDose: med.dosage,
          recommendedDose: med.dosage,
          isAppropriate: true,
          warnings: ["Unable to verify dosage"],
        })
      }
    }

    return verifications
  }

  private async findAlternatives(medications: any[], patient: any): Promise<Alternative[]> {
    const alternatives: Alternative[] = []

    for (const med of medications) {
      try {
        const result = await huggingFaceClient.findAlternatives(med.name, patient.age, patient.conditions || [])

        if (result.alternatives) {
          alternatives.push(
            ...result.alternatives.map((alt: any) => ({
              originalMedication: med.name,
              alternativeName: alt.name,
              scientificName: alt.scientificName || alt.name,
              reason: alt.reason,
              dosageAdjustment: alt.dosageAdjustment,
            })),
          )
        }
      } catch (error) {
        console.error(`Alternative finding error for ${med.name}:`, error)
      }
    }

    return alternatives
  }

  private generateSummary(
    interactions: DrugInteraction[],
    dosageVerifications: DosageVerification[],
    alternatives: Alternative[],
  ): string {
    const parts: string[] = []

    if (interactions.length > 0) {
      const severeCount = interactions.filter((i) => i.severity === "severe").length
      const moderateCount = interactions.filter((i) => i.severity === "moderate").length

      if (severeCount > 0) {
        parts.push(`${severeCount} severe interaction(s) detected`)
      }
      if (moderateCount > 0) {
        parts.push(`${moderateCount} moderate interaction(s) found`)
      }
    } else {
      parts.push("No significant drug interactions detected")
    }

    const inappropriateDoses = dosageVerifications.filter((d) => !d.isAppropriate).length
    if (inappropriateDoses > 0) {
      parts.push(`${inappropriateDoses} dosage(s) may need adjustment`)
    } else {
      parts.push("All dosages appear appropriate")
    }

    if (alternatives.length > 0) {
      parts.push(`${alternatives.length} alternative medication(s) available`)
    }

    return parts.join(". ") + "."
  }

  private calculateConfidence(
    interactions: DrugInteraction[],
    dosageVerifications: DosageVerification[],
    alternatives: Alternative[],
  ): number {
    // Simple confidence calculation based on successful analyses
    const totalAnalyses = interactions.length + dosageVerifications.length + alternatives.length
    if (totalAnalyses === 0) return 0.5

    // Base confidence of 0.8, adjusted based on analysis completeness
    return Math.min(0.95, 0.8 + totalAnalyses * 0.02)
  }
}

export const medicalAnalyzer = new MedicalAnalyzer()
