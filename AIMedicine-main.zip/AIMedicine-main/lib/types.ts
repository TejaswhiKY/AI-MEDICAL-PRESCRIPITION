// Type definitions for the medical prescription system

export interface Medication {
  id: string
  name: string
  scientificName?: string
  rxcui?: string
  dosage: string
  frequency: string
  route: string
}

export interface Patient {
  age: number
  weight?: number
  conditions?: string[]
  allergies?: string[]
}

export interface DrugInteraction {
  severity: "mild" | "moderate" | "severe"
  description: string
  medications: string[]
  recommendation: string
}

export interface DosageVerification {
  medication: string
  prescribedDose: string
  recommendedDose: string
  isAppropriate: boolean
  warnings?: string[]
}

export interface Alternative {
  originalMedication: string
  alternativeName: string
  scientificName: string
  reason: string
  dosageAdjustment?: string
}

export interface AnalysisRequest {
  medications: Medication[]
  patient: Patient
  analysisType: "interaction" | "dosage" | "alternatives" | "comprehensive"
}

export interface AnalysisResponse {
  interactions: DrugInteraction[]
  dosageVerifications: DosageVerification[]
  alternatives: Alternative[]
  summary: string
  confidence: number
}
