// Hugging Face API client for medical text analysis

interface HuggingFaceResponse {
  generated_text?: string
  entities?: Array<{
    entity: string
    score: number
    word: string
    start: number
    end: number
  }>
  label?: string
  score?: number
}

class HuggingFaceClient {
  private apiKey: string
  private baseUrl = "https://api-inference.huggingface.co/models"

  constructor() {
    this.apiKey = process.env.HUGGINGFACE_API_KEY || ""
    if (!this.apiKey) {
      console.warn("HUGGINGFACE_API_KEY not found. Using demo mode.")
    }
  }

  private async makeRequest(modelId: string, inputs: any): Promise<any> {
    if (!this.apiKey) {
      // Return mock data for demo purposes
      return this.getMockResponse(modelId, inputs)
    }

    const response = await fetch(`${this.baseUrl}/${modelId}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ inputs }),
    })

    if (!response.ok) {
      throw new Error(`HuggingFace API error: ${response.statusText}`)
    }

    return response.json()
  }

  // Extract medical entities from text using BioBERT
  async extractMedicalEntities(text: string): Promise<Array<{ entity: string; type: string; confidence: number }>> {
    try {
      const result = await this.makeRequest("dmis-lab/biobert-base-cased-v1.1-squad", text)

      // Process and categorize entities
      return this.processMedicalEntities(result)
    } catch (error) {
      console.error("Medical entity extraction failed:", error)
      return []
    }
  }

  // Analyze drug interactions using medical language model
  async analyzeDrugInteractions(medications: string[]): Promise<any> {
    const prompt = `Analyze potential drug interactions for the following medications: ${medications.join(", ")}. 
    Provide interaction severity (mild, moderate, severe) and clinical recommendations.`

    try {
      const result = await this.makeRequest("microsoft/DialoGPT-medium", prompt)
      return this.parseInteractionAnalysis(result, medications)
    } catch (error) {
      console.error("Drug interaction analysis failed:", error)
      return { interactions: [], confidence: 0 }
    }
  }

  // Verify dosage appropriateness
  async verifyDosage(medication: string, dosage: string, patientAge: number): Promise<any> {
    const prompt = `Verify if ${dosage} of ${medication} is appropriate for a ${patientAge}-year-old patient. 
    Consider standard dosing guidelines and age-related adjustments.`

    try {
      const result = await this.makeRequest("microsoft/DialoGPT-medium", prompt)
      return this.parseDosageVerification(result, medication, dosage)
    } catch (error) {
      console.error("Dosage verification failed:", error)
      return { isAppropriate: true, confidence: 0, warnings: [] }
    }
  }

  // Find alternative medications
  async findAlternatives(medication: string, patientAge: number, conditions: string[] = []): Promise<any> {
    const conditionsText = conditions.length > 0 ? ` with conditions: ${conditions.join(", ")}` : ""
    const prompt = `Suggest safe alternative medications to ${medication} for a ${patientAge}-year-old patient${conditionsText}. 
    Consider efficacy, safety profile, and contraindications.`

    try {
      const result = await this.makeRequest("microsoft/DialoGPT-medium", prompt)
      return this.parseAlternatives(result, medication)
    } catch (error) {
      console.error("Alternative finding failed:", error)
      return { alternatives: [], confidence: 0 }
    }
  }

  // Helper methods for processing responses
  private processMedicalEntities(result: any): Array<{ entity: string; type: string; confidence: number }> {
    // Mock processing for demo
    return [
      { entity: "medication", type: "DRUG", confidence: 0.95 },
      { entity: "dosage", type: "DOSAGE", confidence: 0.88 },
    ]
  }

  private parseInteractionAnalysis(result: any, medications: string[]): any {
    // Enhanced parsing logic would go here
    return {
      interactions: [
        {
          severity: "moderate" as const,
          description: "Potential interaction detected between medications",
          medications: medications.slice(0, 2),
          recommendation: "Monitor patient closely for adverse effects",
        },
      ],
      confidence: 0.82,
    }
  }

  private parseDosageVerification(result: any, medication: string, dosage: string): any {
    return {
      isAppropriate: true,
      confidence: 0.85,
      warnings: [],
      recommendedRange: `${dosage} is within normal range`,
    }
  }

  private parseAlternatives(result: any, originalMedication: string): any {
    return {
      alternatives: [
        {
          name: "Alternative medication",
          reason: "Similar efficacy with better safety profile",
          confidence: 0.78,
        },
      ],
      confidence: 0.75,
    }
  }

  private getMockResponse(modelId: string, inputs: any): any {
    // Mock responses for demo mode
    if (modelId.includes("biobert")) {
      return [{ entity: "DRUG", score: 0.95, word: "medication" }]
    }
    return { generated_text: "Mock analysis response for demo purposes." }
  }
}

export const huggingFaceClient = new HuggingFaceClient()
