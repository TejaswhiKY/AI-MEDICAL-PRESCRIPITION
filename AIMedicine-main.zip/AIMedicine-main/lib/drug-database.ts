// Mock drug database for RxCUI mapping and drug information
// In production, this would connect to real medical databases like RxNorm

export interface DrugInfo {
  name: string
  scientificName: string
  rxcui: string
  category: string
  commonDosages: string[]
  contraindications: string[]
  interactions: string[]
}

export const drugDatabase: Record<string, DrugInfo> = {
  lisinopril: {
    name: "Lisinopril",
    scientificName: "Lisinopril",
    rxcui: "29046",
    category: "ACE Inhibitor",
    commonDosages: ["2.5mg", "5mg", "10mg", "20mg", "40mg"],
    contraindications: ["Pregnancy", "Angioedema history"],
    interactions: ["Potassium supplements", "NSAIDs", "Lithium"],
  },
  metformin: {
    name: "Metformin",
    scientificName: "Metformin hydrochloride",
    rxcui: "6809",
    category: "Biguanide",
    commonDosages: ["500mg", "850mg", "1000mg"],
    contraindications: ["Severe kidney disease", "Metabolic acidosis"],
    interactions: ["Alcohol", "Contrast dye", "Furosemide"],
  },
  atorvastatin: {
    name: "Atorvastatin",
    scientificName: "Atorvastatin calcium",
    rxcui: "83367",
    category: "Statin",
    commonDosages: ["10mg", "20mg", "40mg", "80mg"],
    contraindications: ["Active liver disease", "Pregnancy"],
    interactions: ["Grapefruit juice", "Warfarin", "Digoxin"],
  },
  amlodipine: {
    name: "Amlodipine",
    scientificName: "Amlodipine besylate",
    rxcui: "17767",
    category: "Calcium Channel Blocker",
    commonDosages: ["2.5mg", "5mg", "10mg"],
    contraindications: ["Severe aortic stenosis"],
    interactions: ["Simvastatin", "Cyclosporine"],
  },
}

export function findDrugInfo(drugName: string): DrugInfo | null {
  const normalizedName = drugName.toLowerCase().trim()
  return drugDatabase[normalizedName] || null
}

export function searchDrugs(query: string): DrugInfo[] {
  const normalizedQuery = query.toLowerCase()
  return Object.values(drugDatabase).filter(
    (drug) =>
      drug.name.toLowerCase().includes(normalizedQuery) || drug.scientificName.toLowerCase().includes(normalizedQuery),
  )
}

export function getRxCUI(drugName: string): string | null {
  const drugInfo = findDrugInfo(drugName)
  return drugInfo?.rxcui || null
}
