"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Plus } from "lucide-react"
import type { Medication } from "@/lib/types"

interface MedicationInputProps {
  medications: Medication[]
  onMedicationsChange: (medications: Medication[]) => void
}

export function MedicationInput({ medications, onMedicationsChange }: MedicationInputProps) {
  const [newMedication, setNewMedication] = useState<Partial<Medication>>({
    name: "",
    dosage: "",
    frequency: "",
    route: "oral",
  })

  const addMedication = () => {
    if (newMedication.name && newMedication.dosage) {
      const medication: Medication = {
        id: Date.now().toString(),
        name: newMedication.name,
        dosage: newMedication.dosage,
        frequency: newMedication.frequency || "once daily",
        route: newMedication.route || "oral",
      }
      onMedicationsChange([...medications, medication])
      setNewMedication({ name: "", dosage: "", frequency: "", route: "oral" })
    }
  }

  const removeMedication = (id: string) => {
    onMedicationsChange(medications.filter((med) => med.id !== id))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Medications</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Medications */}
        {medications.length > 0 && (
          <div className="space-y-2">
            <Label>Current Medications:</Label>
            {medications.map((med) => (
              <div key={med.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <div className="font-medium">{med.name}</div>
                  <div className="text-sm text-gray-600">
                    {med.dosage} • {med.frequency} • {med.route}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeMedication(med.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {/* Add New Medication */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="med-name">Medication Name</Label>
            <Input
              id="med-name"
              placeholder="e.g., Lisinopril"
              value={newMedication.name}
              onChange={(e) => setNewMedication({ ...newMedication, name: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="med-dosage">Dosage</Label>
            <Input
              id="med-dosage"
              placeholder="e.g., 10mg"
              value={newMedication.dosage}
              onChange={(e) => setNewMedication({ ...newMedication, dosage: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="med-frequency">Frequency</Label>
            <Input
              id="med-frequency"
              placeholder="e.g., twice daily"
              value={newMedication.frequency}
              onChange={(e) => setNewMedication({ ...newMedication, frequency: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="med-route">Route</Label>
            <Input
              id="med-route"
              placeholder="e.g., oral"
              value={newMedication.route}
              onChange={(e) => setNewMedication({ ...newMedication, route: e.target.value })}
            />
          </div>
        </div>

        <Button onClick={addMedication} className="w-full" disabled={!newMedication.name || !newMedication.dosage}>
          <Plus className="h-4 w-4 mr-2" />
          Add Medication
        </Button>
      </CardContent>
    </Card>
  )
}
