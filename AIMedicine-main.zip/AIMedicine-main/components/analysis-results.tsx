"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, CheckCircle, Info, Pill, RefreshCw } from "lucide-react"
import type { AnalysisResponse } from "@/lib/types"

interface AnalysisResultsProps {
  result: AnalysisResponse
}

export function AnalysisResults({ result }: AnalysisResultsProps) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "severe":
        return "bg-red-100 text-red-800 border-red-200"
      case "moderate":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "mild":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "severe":
        return <AlertTriangle className="h-4 w-4" />
      case "moderate":
        return <Info className="h-4 w-4" />
      default:
        return <CheckCircle className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Summary Card */}
      <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
        <CardHeader>
          <CardTitle className="text-blue-800 dark:text-blue-200">Analysis Summary</CardTitle>
          <CardDescription className="text-blue-700 dark:text-blue-300">{result.summary}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm font-medium">Confidence Score:</span>
            <Badge variant="secondary">{Math.round(result.confidence * 100)}%</Badge>
          </div>
          <Progress value={result.confidence * 100} className="h-2" />
        </CardContent>
      </Card>

      {/* Drug Interactions */}
      {result.interactions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              Drug Interactions ({result.interactions.length})
            </CardTitle>
            <CardDescription>Potential interactions detected between prescribed medications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.interactions.map((interaction, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {getSeverityIcon(interaction.severity)}
                    <Badge className={getSeverityColor(interaction.severity)}>
                      {interaction.severity.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-500">{interaction.medications.join(" + ")}</div>
                </div>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">{interaction.description}</p>
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-md">
                  <p className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">Recommendation:</p>
                  <p className="text-sm text-blue-700 dark:text-blue-300">{interaction.recommendation}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Dosage Verifications */}
      {result.dosageVerifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5 text-green-600" />
              Dosage Verification ({result.dosageVerifications.length})
            </CardTitle>
            <CardDescription>Analysis of prescribed dosages for patient demographics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.dosageVerifications.map((verification, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{verification.medication}</h4>
                  <Badge
                    className={verification.isAppropriate ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                  >
                    {verification.isAppropriate ? "Appropriate" : "Needs Review"}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Prescribed:</span> {verification.prescribedDose}
                  </div>
                  <div>
                    <span className="font-medium">Recommended:</span> {verification.recommendedDose}
                  </div>
                </div>
                {verification.warnings && verification.warnings.length > 0 && (
                  <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-md">
                    <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200 mb-1">Warnings:</p>
                    <ul className="text-sm text-yellow-700 dark:text-yellow-300 list-disc list-inside">
                      {verification.warnings.map((warning, idx) => (
                        <li key={idx}>{warning}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Alternative Medications */}
      {result.alternatives.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5 text-purple-600" />
              Alternative Medications ({result.alternatives.length})
            </CardTitle>
            <CardDescription>Safer or more effective alternatives for consideration</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.alternatives.map((alternative, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-medium">{alternative.alternativeName}</h4>
                    <p className="text-sm text-gray-600">{alternative.scientificName}</p>
                  </div>
                  <Badge variant="outline">Alternative to {alternative.originalMedication}</Badge>
                </div>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">{alternative.reason}</p>
                {alternative.dosageAdjustment && (
                  <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-md">
                    <p className="text-sm font-medium text-purple-800 dark:text-purple-200 mb-1">Dosage Adjustment:</p>
                    <p className="text-sm text-purple-700 dark:text-purple-300">{alternative.dosageAdjustment}</p>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* No Issues Found */}
      {result.interactions.length === 0 && result.alternatives.length === 0 && (
        <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
          <CardContent className="text-center py-8">
            <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-green-800 dark:text-green-200 mb-2">All Clear!</h3>
            <p className="text-green-700 dark:text-green-300">
              No significant drug interactions or dosage concerns detected for this prescription combination.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
